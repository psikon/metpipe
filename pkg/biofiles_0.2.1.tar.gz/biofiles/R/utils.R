recycle <- function (val, len) {
  lv <- length(val)
  if (len > lv) {
    val <- c(rep(val, len%/%lv), val[seq_len(len%%lv)])
  }
  val
}


#' @autoImports
ellipsize <- function(obj, width = getOption("width"), ellipsis = "...") {
  str <- encodeString(obj)
  base::ifelse(base::nchar(str) > width - 1,
               paste0(base::substring(str, 1, width - base::nchar(ellipsis) - 1), ellipsis),
               str)
}


#' @autoImports
is_compound <- function (x) {
  if (is(x, "gbFeatureList")) {
    return(vapply(x, function (f) !is.na(f@location@compound), logical(1)))
  } else if (is(x, "gbFeature")) {
    return(!is.na(x@location@compound))
  } else if (is(x, "gbLocation")) {
    return(!is.na(x@compound))
  }
}


#' @autoImports
getCompounds <- function (x) {
  x <- x[base::which(is_compound(x))]
  if (length(x) == 0) return(NA_real_) 
  cL <- vapply(x, function (f) base::nrow(f@location@range), integer(1))
  cL
}


#' @autoImports
expandIds <- function (x) {
  cmp_pos <- base::Position(is_compound, x)
  if (is.na(cmp_pos)) {
    return(list(ids=index(x, FALSE), keys=key(x, FALSE)))
  }
  xHead <- x[seq_len(cmp_pos - 1)]
  xCmp <- x[cmp_pos]
  L <- length(x)
  xTail <- if (cmp_pos + 1 <= L) {
    x[seq.int(cmp_pos +  1, L)]
  } else {
    new('gbFeatureList')
  }
  id1 <- list(ids=index(xHead, FALSE), keys=key(xHead, FALSE))
  nC <- getCompounds(xCmp)
  id2 <- list(ids=rep(index(xCmp, FALSE), nC),
              keys=rep(key(xCmp, FALSE), nC))
  id3 <- list(ids=index(xTail, FALSE), keys=key(xTail, FALSE))
  base::Map(function(a, b, c) c(a, b, c), a=id1, b=id2, c=Recall(xTail))
}


#' @importFrom stats setNames
#' @autoImports
.access <- function (x, which, dbxrefs, use.names = TRUE) {
  q <- x@qualifiers
  n <- length(q)
  els <- c(which[which != 'db_xref' & which != '\\bdb_xref\\b'], dbxrefs)
  
  if (n == 0) {
    ans <- rep(NA_character_, length(els))
    if (use.names)
      return( setNames(ans, rmisc::trim(els, "\\\\b")) )
    else
      return( ans )
  }
  
  if (length(which) == 1) {
    idx <- grepl(which, names(q))
    if (any(idx))
      ans <- q[idx]
    else
      ans <- setNames(rep(NA_character_, length(els)),
                      rmisc::trim(which, "\\\\b"))
  } 
  else {
    idx <- base::lapply(which, grepl, names(q))
    ans <- base::lapply(idx, function(i) q[i])
    na <- which(vapply(ans, length, numeric(1)) == 0)
    if (length(na) > 0) {
      for (i in na) {
        ans[[i]] <- setNames(NA_character_, nm=rmisc::trim(which, "\\\\b")[i])
      }
    }
  }
  ans <- base::unlist(ans)
  if (length(dbxrefs) > 0) {
    dbx_ <- names(ans) == 'db_xref'
    dbx <- strsplit(ans[dbx_], ':')
    dbx_nm <- vapply(dbx, `[`, 1, FUN.VALUE=character(1), USE.NAMES=FALSE)
    dbx_val <- vapply(dbx, `[`, 2, FUN.VALUE=character(1), USE.NAMES=FALSE)
    ans <- c(ans[!dbx_], setNames(dbx_val[base::match(dbxrefs, dbx_nm)], dbxrefs))
  }
  
  return( if (use.names) ans else unname(ans) )
}


#' @autoImports
.qualAccess <- function (x, which = "", fixed = FALSE, use.names=TRUE) {
  dbxrefs <- NULL
  dbx <- grepl('db_xref:.+', which)
  if (any(dbx)) {
    dbxrefs <- strsplitN(which[dbx], ':', 2)
    which <- c(which[!dbx], 'db_xref')
  }
  if (fixed) {
    which <- rmisc::wrap(which, "\\b")
  }
  if (is(x, "gbFeature")) {
    .access(x, which, dbxrefs, use.names)
  } else if (is(x, "gbFeatureList")) {
    base::lapply(x, .access, which, dbxrefs, use.names)
  }
}


#' @autoImports
.simplify <- function (x, unlist = TRUE) {
  if (length(len <- base::unique(unlist(base::lapply(x, length)))) > 1L) {
    return(x)
  }
  if (len == 1L && unlist) {
    unlist(x, recursive=FALSE)
  } else if (len >= 1L) {
    n <- length(x)
    r <- base::as.vector(unlist(x, recursive=FALSE))
    if (prod(d <- c(len, n)) == length(r)) {
      return(data.frame(stringsAsFactors=FALSE,
                        matrix(r, nrow=n, byrow=TRUE,
                               dimnames=if (!(is.null(nm <- names(x[[1L]]))))
                                 list(NULL, nm))))
    } else {
      x
    }
  } else {
    x
  }
}


#' @autoImports
.seqAccess <- function (x) {
  seq <- .sequence(x)
  
  if (length(seq) == 0) return(seq)
  
  SEQF <- match.fun(class(seq))
  if (is(x, "gbFeature")) {
    seq <- merge_seq(seq, x, SEQF)
  } else if (is(x, "gbFeatureList")) {
    seq <- Reduce(append, lapply(x, merge_seq, seq=seq, SEQF=SEQF))
  }
  seq
}

# merge Sequences
#' @autoImports
merge_seq <- function (seq, x, SEQF) {
  if (length(start(x)) == 1L) {
    outseq <- XVector::subseq(x=seq, start=start(x), end=end(x))
  } else {
    outseq <- do.call(Biostrings::xscat,
                      base::Map(XVector::subseq, x=seq, start=start(x), end=end(x))
                      )
  }
  outseq <- SEQF(outseq)
  outseq@ranges@NAMES <- .defline(x)
  outseq
}


#' @autoImports
parse_dbsource <- function (dbsource) {
  if (is.na(dbsource)) {
    '|gb|'
  }
  else {
    db <- strsplitN(dbsource, ": | ", 1L)
    db <- switch(db, accession='gb', REFSEQ='ref', db)
    paste0('|', db, '|')
  }
}
