.GBFIELDS <- c("@G@I","accession","comment","date","dblink",
               "dbsource","definition","division","features",
               "keywords","length","lineage","locus","organism",
               "references","sequence","source","topology",
               "type","version")
