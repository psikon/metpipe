library(testthat)
library(biofiles)
test_package("biofiles")