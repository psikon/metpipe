# Uploading UIDs to the Entrez history server #############################

id <- c(194680922,50978626,28558982,9507199,6678417)
p <- epost(id, "protein")
p
