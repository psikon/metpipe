## Perform a global Entrez Search

# Determine the number of records for "Chlamydia psittaci" in Entrez
egquery("Chlamydia psittaci")
