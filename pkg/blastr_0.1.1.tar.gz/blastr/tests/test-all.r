library(testthat)
library(blastr)
test_package("blastr")