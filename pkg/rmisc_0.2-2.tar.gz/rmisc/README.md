rmisc
=====

Various little utility functions that recur in other packages of mine or which I rely upon when using R interactively.
